//
//  ConverseView.swift
//  Conversetemp
//
//  Created by Stuti Bhardwaj on 02/02/26.
//

import SwiftUI

struct ConverseView: View {
    var body: some View {
        
        NavigationStack{
            ScrollView{
                
                VStack(spacing : 10){
                    CommunityCardView()
                    CommunityCardView()
                    CommunityCardView()
                    CommunityCardView()
                    CommunityCardView()
                }
                .padding()
                
                
            }
            .navigationTitle("Community")
            .navigationBarTitleDisplayMode(.large)
            .toolbar{
                ToolbarItem(placement : .topBarTrailing){
                    Button{
                        
                    }
                    label : {
                        Image(systemName: "square.and.pencil")
                            .foregroundStyle(Color("primary"))
                            .clipShape(.circle)
                    }
                }
            }
        }
        
    }
}

#Preview {
    ConverseView()
}
