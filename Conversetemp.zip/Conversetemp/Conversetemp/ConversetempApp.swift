//
//  ConversetempApp.swift
//  Conversetemp
//
//  Created by Stuti Bhardwaj on 02/02/26.
//

import SwiftUI

@main
struct ConversetempApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
